

// Empty JS for your own code to be here
/*
$("#msg").html(chrome.i18n.getMessage('msg'));
$("#download0").html(chrome.i18n.getMessage('copy'));
$("#download1").html(chrome.i18n.getMessage('download'));
$("#or").html(chrome.i18n.getMessage('or'));
*/